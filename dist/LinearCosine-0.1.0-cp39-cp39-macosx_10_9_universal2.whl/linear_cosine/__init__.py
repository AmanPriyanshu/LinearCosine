from .linear_cosine import cosine_similarity

__all__ = ['cosine_similarity']
__version__ = '0.1.0'