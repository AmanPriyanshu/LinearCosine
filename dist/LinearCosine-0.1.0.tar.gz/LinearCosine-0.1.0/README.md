# LinearCosine
LinearCosine: Adding beats multiplying for lower-precision efficient cosine similarity
